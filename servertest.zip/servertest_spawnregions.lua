function SpawnRegions()
	return {
		{ name = "Muldraugh, KY", file = "media/maps/Muldraugh, KY/spawnpoints.lua" },
		{ name = "Riverside, KY", file = "media/maps/Riverside, KY/spawnpoints.lua" },
		{ name = "Rosewood, KY", file = "media/maps/Rosewood, KY/spawnpoints.lua" },
		{ name = "West Point, KY", file = "media/maps/West Point, KY/spawnpoints.lua" },
		{ name = "RavenCreek", file = "media/maps/RavenCreek/spawnpoints.lua" },
		{ name = "Basements", file = "media/maps/Basements/spawnpoints.lua" },
		{ name = "AZSpawn", file = "media/maps/AZSpawn/spawnpoints.lua" },
		{ name = "Mansion", file = "media/maps/Mansion/spawnpoints.lua" },
		{ name = "tvalley", file = "media/maps/tvalley/spawnpoints.lua" },
		{ name = "tmarch", file = "media/maps/tmarch/spawnpoints.lua" },
		{ name = "tluisville", file = "media/maps/tluisville/spawnpoints.lua" },
		{ name = "FortRedstone", file = "media/maps/FortRedstone/spawnpoints.lua" },
		{ name = "Greenleaf", file = "media/maps/Greenleaf/spawnpoints.lua" },
		{ name = "MREX", file = "media/maps/MREX/spawnpoints.lua" },
		{ name = "NewEkron", file = "media/maps/NewEkron/spawnpoints.lua" },
		{ name = "vehicle_interior", file = "media/maps/vehicle_interior/spawnpoints.lua" },
		{ name = "west_point_expansion", file = "media/maps/west_point_expansion/spawnpoints.lua" },
		{ name = "MotoriousExpandedSpawnZones", file = "media/maps/MotoriousExpandedSpawnZones/spawnpoints.lua" },
	}
end
